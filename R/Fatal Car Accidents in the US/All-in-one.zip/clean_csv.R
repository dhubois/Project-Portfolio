library(tidyverse)

clean_csv <- function(file_path) {
  #input MUST be a string including the "/folder/file.csv" path
  df_header <- read_csv(file_path, skip = 5, n_max = 3)
  
  #Slice, then bring names together using `_` separator
  header_names <- paste(as.character(slice(df_header, 1)), as.character(slice(df_header, 2)), 
                        as.character(slice(df_header, 3)), sep = "_")
  
  #clean the column names
  header_names <- header_names %>% 
    str_replace_all(pattern = " ", replacement = "_") %>% 
    str_remove(pattern = "NA\\_NA|^NA\\_|\\_NA$") %>% 
    str_replace_all(pattern = "\\.|\\,", replacement = "") %>% 
    str_remove(pattern = "_$")
  
  #Rename first column to `Year`
  header_names[1] <- "Year"
  
  #read in data with cleaned names
  tbl <- read_csv(file_path, skip = 9, col_names = header_names, n_max = 11)
  
  #remove unnecessary columns
  tbl[,-length(tbl)]
  
  return(tbl)
}




# This function cleans all the DATE files' headers
clean_date <- function(file_path) {
  #input MUST be a string including the "/folder/file.csv" path
  df_header <- read_csv(file_path, skip = 5, n_max = 3)
  
  #Slice, then bring names together using `_` separator
  header_names <- paste(as.character(slice(df_header, 2)), as.character(slice(df_header, 3)), sep = "_")
  
  #clean the column names
  header_names <- header_names %>% 
    str_replace_all(pattern = " ", replacement = "_") %>% 
    str_remove_all(pattern = "NA\\_NA|^NA\\_|\\_NA$") %>% 
    str_replace_all(pattern = "\\.|\\,", replacement = "") %>% 
    str_remove(pattern = "_$")
  
  #Rename first column to `Year`
  header_names[1] <- "Year"
  
  #read in data with cleaned names
  tbl <- read_csv(file_path, skip = 9, col_names = header_names, n_max = 11)
  
  #remove unnecessary columns
  #tbl <- tbl[,-length(tbl)]
  
  return(tbl)
}